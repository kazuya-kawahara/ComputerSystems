#include <stdio.h>

struct node {
  int val;
  struct node *next;
  struct node *prev;
};

int put(struct node *tail, int val) {
  struct node *new;
  new = malloc(sizeof(struct node));
  if(new==NULL) return -1;

  new->val = val;
  new->prev = tail->prev;
  tail->prev = new;
  return 0;
}

int get(struct node *head) {
  struct node *cur;
  int result = -1;
  cur = head->next;
  if (cur->val != -1) {
    head->next = cur->next;
    result = cur->val;
    free(cur);
  }
  return result;
}

int delete(struct node *head, int val) {
  struct node *prev, *cur;
  int result = -1;

  for (cur = head->next, prev = head; cur->val != -1;
       cur = cur->next, prev = prev->next) {
    if (cur->val == val) {
      prev->next = cur->next;
      result = cur->val;
      free(cur);
      break;
    }
  }
  return result;
}

void display(struct node *head){
  struct node *cur;
  int line = 1;
  for (cur = head->next; cur->val != -1 ;cur=cur->next) {
    printf("%d: %d\n",line++, cur->val);
  }
}


int main() {
  struct node head;
  struct node tail;
  head.next = &tail;
  tail.prev = &head;
  int nums[] = {9,8,7,6,5,4,3,2,1,0};
  int i;
  for (i = 0; i < 10; i++){
    int res = put(&tail, nums[i]);
    if (res != 0) return 1;
  }
  get(&head);
  delete(&head, 9);
  delete(&head, 5);
  delete(&head, 10);
  display(&head);
  return 0;
}
